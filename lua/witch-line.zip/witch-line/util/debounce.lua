local unpack = unpack

return function(func, delay)
    local timer, running = nil, false

    return function(...)
        if not timer then
            timer = assert((vim.uv or vim.loop).new_timer())
        elseif running then
            timer:stop()
        end
        running = true

        local args = { ... }
        timer:start(
            delay,
            0,
            vim.schedule_wrap(function()
                running = false
                func(unpack(args))
            end)
        )
    end
end
