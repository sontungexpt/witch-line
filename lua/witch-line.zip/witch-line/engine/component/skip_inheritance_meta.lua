return {
    -- identity / registry state
    id = true,
    ___loaded = true,
    ___renderable = true,

    -- runtime cache / computed state
    ___hidden = true,
    ___use_returned_style = true,
    ___hl_name = true,
    ___left_hl_name = true,
    ___right_hl_name = true,

    --- Considering allow inherit this fiedl
    init = true,

    -- lifecycle hooks (IMPORTANT: should NOT be inherited blindly)
    update = true,
    pre_update = true,
    post_update = true,
    with_session = true, -- nên skip luôn

    -- framework internal flags
    ___click_handler = true,
    ___plug_provided = true,
}
